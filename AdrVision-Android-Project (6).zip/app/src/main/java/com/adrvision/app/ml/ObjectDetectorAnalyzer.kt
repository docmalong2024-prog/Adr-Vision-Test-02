package com.adrvision.app.ml

import android.graphics.RectF
import androidx.annotation.OptIn
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.adrvision.app.domain.model.DetectedObjectUI
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.objects.ObjectDetection
import com.google.mlkit.vision.objects.ObjectDetector
import com.google.mlkit.vision.objects.defaults.ObjectDetectorOptions

/**
 * ObjectDetectorAnalyzer: Lớp triển khai ImageAnalysis.Analyzer của CameraX.
 * Chạy trên một background thread riêng biệt để không gây block UI thread.
 */
class ObjectDetectorAnalyzer(
    private val onObjectsDetected: (List<DetectedObjectUI>, Long) -> Unit
) : ImageAnalysis.Analyzer {

    // Cấu hình ML Kit Object Detector ở chế độ STREAM_MODE để tối ưu tracking liên tục
    private val options = ObjectDetectorOptions.Builder()
        .setDetectorMode(ObjectDetectorOptions.STREAM_MODE)
        .enableMultipleObjects() // Cho phép phát hiện nhiều vật thể cùng lúc
        .enableClassification() // Bật phân loại nhãn (Person, Fashion, Home goods, etc.)
        .build()

    private val detector: ObjectDetector = ObjectDetection.getClient(options)

    @OptIn(ExperimentalGetImage::class)
    override fun analyze(imageProxy: ImageProxy) {
        val mediaImage = imageProxy.image
        if (mediaImage == null) {
            imageProxy.close()
            return
        }

        val startTime = System.currentTimeMillis()

        // Chuyển đổi khung hình từ CameraX sang InputImage của ML Kit kèm thông tin góc xoay
        val inputImage = InputImage.fromMediaImage(
            mediaImage,
            imageProxy.imageInfo.rotationDegrees
        )

        val imageWidth = imageProxy.width
        val imageHeight = imageProxy.height
        val rotationDegrees = imageProxy.imageInfo.rotationDegrees

        // Kích thước khung hình thực tế sau khi tính góc xoay
        val isRotated = rotationDegrees == 90 || rotationDegrees == 270
        val orientedWidth = if (isRotated) imageHeight else imageWidth
        val orientedHeight = if (isRotated) imageWidth else imageHeight

        detector.process(inputImage)
            .addOnSuccessListener { detectedObjects ->
                val inferenceTime = System.currentTimeMillis() - startTime

                val mappedObjects = detectedObjects.mapNotNull { detectedObject ->
                    val boundingBox = detectedObject.boundingBox
                    val primaryLabel = detectedObject.labels.firstOrNull()

                    val labelText = primaryLabel?.text ?: "Object"
                    val confidence = primaryLabel?.confidence ?: 0.65f
                    val trackingId = detectedObject.trackingId

                    // Chuẩn hóa tọa độ Bounding Box về tỉ lệ (0f .. 1f) để vẽ trên mọi kích thước màn hình
                    val normalizedRect = RectF(
                        boundingBox.left.toFloat() / orientedWidth,
                        boundingBox.top.toFloat() / orientedHeight,
                        boundingBox.right.toFloat() / orientedWidth,
                        boundingBox.bottom.toFloat() / orientedHeight
                    )

                    DetectedObjectUI(
                        trackingId = trackingId,
                        label = translateLabel(labelText),
                        confidence = confidence,
                        normalizedBoundingBox = normalizedRect
                    )
                }

                onObjectsDetected(mappedObjects, inferenceTime)
            }
            .addOnFailureListener { e ->
                e.printStackTrace()
            }
            .addOnCompleteListener {
                // QUAN TRỌNG: Luôn gọi imageProxy.close() sau khi xử lý xong
                // Nếu quên đóng, CameraX sẽ ngừng cung cấp khung hình mới (bị drop frame hoàn toàn)
                imageProxy.close()
            }
    }

    /**
     * Hàm dịch nhãn ML Kit mặc định sang tiếng Việt thân thiện
     */
    private fun translateLabel(rawLabel: String): String {
        return when (rawLabel.lowercase()) {
            "person" -> "Người"
            "food" -> "Thức ăn"
            "fashion good" -> "Thời trang"
            "home good" -> "Đồ gia dụng"
            "place" -> "Địa điểm"
            "plant" -> "Thực vật"
            "vehicle" -> "Phương tiện"
            else -> rawLabel.replaceFirstChar { it.uppercase() }
        }
    }
}