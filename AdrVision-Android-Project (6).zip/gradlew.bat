@rem Gradle batch script for Windows
gradle %*
